We would like to level up this whole repo by doing the following:

1) Rebuild using TS
2) Use Moralis SDK v2
3) Use web3uikit for UI
4) Have storyboard
5) have amotic design and folder structure
6) Have tests
