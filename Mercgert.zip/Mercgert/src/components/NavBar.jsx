import { useLocation } from "react-router";
import { Menu } from "antd";
import { NavLink } from "react-router-dom";

function NavBar() {
  const { pathname } = useLocation();

  return (
    <Menu
      theme="light"
      mode="horizontal"
      style={{
        display: "flex",
        fontSize: "17px",
        fontWeight: "500",
        width: "100%",
        justifyContent: "center",
      }}
      defaultSelectedKeys={[pathname]}
    >
      <Menu.Item key="/dashboard">
        <NavLink to="/dashboard"> Dashboard</NavLink>
      </Menu.Item>
      <Menu.Item key="/prices">
        <NavLink to="/prices"> Prices</NavLink>
      </Menu.Item>
      <Menu.Item key="/swap">
        <NavLink to="/swap"> Swap</NavLink>
      </Menu.Item>
      <Menu.Item key="overview">
        <NavLink to="/rugchecker"> Rugchecker</NavLink>
      </Menu.Item>
      <Menu.Item key="/rugcheck">
        <NavLink to="/overview"> Overview</NavLink>
      </Menu.Item>
      <Menu.Item key="/erc20transfers">
        <NavLink to="/erc20transfers">💸 Transfers</NavLink>
      </Menu.Item>
      <Menu.Item key="/nftBalance">
        <NavLink to="/nftBalance">🖼 NFTs</NavLink>
      </Menu.Item>
      <Menu.Item key="/contract">
        <NavLink to="/contract">📄 Contract</NavLink>
      </Menu.Item>
    </Menu>
  );
}

export default NavBar;
